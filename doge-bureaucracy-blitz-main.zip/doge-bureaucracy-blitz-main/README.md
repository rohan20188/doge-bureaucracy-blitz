# doge-bureaucracy-blitz
DOGE: Bureaucracy Blitz A satirical browser-based strategy game where you lead the Department of Government Efficiency (DOGE) and try to fix bureaucracy. 
